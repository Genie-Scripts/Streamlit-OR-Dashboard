# app.py (v5.6 週単位分析対応版)
import streamlit as st
import pandas as pd
import traceback
from datetime import datetime, time
import pytz
import plotly.express as px

# --- 整理されたモジュールのインポート ---
from config import style_config, target_loader
from data_processing import loader
from analysis import weekly, periodic, ranking, surgeon, forecasting
from plotting import trend_plots, generic_plots
from reporting import csv_exporter, pdf_exporter
from utils import date_helpers

# --- ページ設定 (必ず最初に実行) ---
st.set_page_config(
    page_title="手術分析ダッシュボード", page_icon="🏥", layout="wide", initial_sidebar_state="expanded"
)
style_config.load_dashboard_css()

# --- セッション状態の初期化 ---
def initialize_session_state():
    if 'processed_df' not in st.session_state: st.session_state['processed_df'] = pd.DataFrame()
    if 'target_dict' not in st.session_state: st.session_state['target_dict'] = {}
    if 'latest_date' not in st.session_state: st.session_state['latest_date'] = None
    if 'current_view' not in st.session_state: st.session_state['current_view'] = 'ダッシュボード'

# --- UI描画関数 ---
def render_sidebar():
    with st.sidebar:
        st.title("🏥 手術分析")
        st.markdown("---")
        views = ["ダッシュボード", "データアップロード", "病院全体分析", "診療科別分析", "術者分析", "将来予測"]
        st.session_state['current_view'] = st.radio("📍 ナビゲーション", views, key="navigation")
        st.markdown("---")
        if not st.session_state.get('processed_df', pd.DataFrame()).empty:
            st.success("✅ データ読み込み済み")
            st.write(f"📊 レコード数: {len(st.session_state['processed_df']):,}")
            if st.session_state.get('latest_date'): st.write(f"📅 最新日付: {st.session_state['latest_date'].strftime('%Y/%m/%d')}")
        else: st.warning("⚠️ データ未読み込み")
        if st.session_state.get('target_dict'): st.success("🎯 目標データ設定済み")
        else: st.info("目標データ未設定")
        st.markdown("---")
        st.info("Version: 5.6 (週単位分析対応)")
        jst = pytz.timezone('Asia/Tokyo')
        st.write(f"現在時刻: {datetime.now(jst).strftime('%H:%M:%S')}")

def render_page_content():
    current_view = st.session_state.get('current_view', 'ダッシュボード')
    if current_view == 'データアップロード':
        render_upload_page()
        return
    df = st.session_state.get('processed_df')
    if df is None or df.empty:
        st.warning("分析を開始するには、「データアップロード」ページでデータを読み込んでください。")
        return
    target_dict = st.session_state.get('target_dict', {})
    latest_date = st.session_state.get('latest_date')
    page_map = {
        "ダッシュボード": render_dashboard_page,
        "病院全体分析": render_hospital_page,
        "診療科別分析": render_department_page,
        "術者分析": render_surgeon_page,
        "将来予測": render_prediction_page,
    }
    page_func = page_map.get(current_view)
    if page_func: page_func(df, target_dict, latest_date)

def render_upload_page():
    st.header("📤 データアップロード")
    base_file = st.file_uploader("基礎データ (CSV)", type="csv")
    update_files = st.file_uploader("追加データ (CSV)", type="csv", accept_multiple_files=True)
    target_file = st.file_uploader("目標データ (CSV)", type="csv")
    if st.button("データ処理を実行", type="primary"):
        with st.spinner("データ処理中..."):
            try:
                if base_file:
                    df = loader.load_and_merge_files(base_file, update_files)
                    st.session_state['processed_df'] = df
                    if not df.empty: st.session_state['latest_date'] = df['手術実施日_dt'].max()
                    st.success(f"データ処理完了。{len(df)}件のレコードが読み込まれました。")
                else: st.warning("基礎データファイルをアップロードしてください。")
                if target_file:
                    st.session_state['target_dict'] = target_loader.load_target_file(target_file)
                    st.success(f"目標データを読み込みました。{len(st.session_state['target_dict'])}件の診療科目標を設定。")
            except Exception as e: st.error(f"エラー: {e}"); st.code(traceback.format_exc())

def render_dashboard_page(df, target_dict, latest_date):
    st.title("🏠 ダッシュボード")
    
    # KPIサマリー（直近4週間）
    kpi_summary = ranking.get_kpi_summary(df, latest_date)
    generic_plots.display_kpi_metrics(kpi_summary)
    
    # 週単位分析の説明
    analysis_end_date = weekly.get_analysis_end_date(latest_date)
    
    if analysis_end_date:
        four_weeks_ago = analysis_end_date - pd.Timedelta(days=27)
        twelve_weeks_ago = analysis_end_date - pd.Timedelta(days=83)
        
        st.info(
            f"📊 **完全週単位分析** - 月曜日起算の完全な週データで分析  \n"
            f"📅 KPI期間: {four_weeks_ago.strftime('%Y/%m/%d')} ～ {analysis_end_date.strftime('%Y/%m/%d')} (直近4週)  \n"
            f"📈 ランキング期間: {twelve_weeks_ago.strftime('%Y/%m/%d')} ～ {analysis_end_date.strftime('%Y/%m/%d')} (直近12週)"
        )
    
    st.header("📈 病院全体 週次トレンド")
    use_complete_weeks = st.toggle(
        "完全週データで分析", 
        value=True, 
        help="週の途中のデータを分析から除外し、月曜〜日曜の完全な週単位で集計します。"
    )
    
    summary = weekly.get_summary(df, use_complete_weeks=use_complete_weeks)
    if not summary.empty:
        fig = trend_plots.create_weekly_summary_chart(summary, "病院全体 週次推移", target_dict)
        st.plotly_chart(fig, use_container_width=True)
    
    st.header("🏆 診療科別ランキング (直近12週)")
    
    if target_dict:
        # 直近12週間のデータでランキング計算
        if analysis_end_date:
            twelve_weeks_ago = analysis_end_date - pd.Timedelta(days=83)  # 12週間 - 1日
            filtered_df = df[
                (df['手術実施日_dt'] >= twelve_weeks_ago) & 
                (df['手術実施日_dt'] <= analysis_end_date)
            ]
        else:
            # フォールバック：従来の方法
            filtered_df = date_helpers.filter_by_period(df, latest_date, "直近90日")
        
        ranking_data = ranking.calculate_achievement_rates(filtered_df, target_dict)
        
        if not ranking_data.empty:
            fig_rank = generic_plots.plot_achievement_ranking(ranking_data)
            st.plotly_chart(fig_rank, use_container_width=True)
            
            # 期間情報の表示
            st.caption(
                f"📊 分析期間: {len(filtered_df)}件のデータ "
                f"({filtered_df['手術実施日_dt'].min().strftime('%Y/%m/%d')} ～ "
                f"{filtered_df['手術実施日_dt'].max().strftime('%Y/%m/%d')})"
            )
    else:
        st.info("目標データをアップロードするとランキングが表示されます。")

def render_hospital_page(df, target_dict, latest_date):
    st.title("🏥 病院全体分析 (完全週データ)")
    
    analysis_end_sunday = weekly.get_analysis_end_date(latest_date)
    if analysis_end_sunday is None:
        st.warning("分析可能な日付データがありません。"); return
        
    excluded_days = (latest_date - analysis_end_sunday).days
    df_complete_weeks = df[df['手術実施日_dt'] <= analysis_end_sunday]
    total_records = len(df_complete_weeks)
    
    col1, col2, col3, col4 = st.columns(4)
    with col1: st.metric("📊 総レコード数", f"{total_records:,}件")
    with col2: st.metric("📅 最新データ日", latest_date.strftime('%Y/%m/%d'))
    with col3: st.metric("🎯 分析終了日", analysis_end_sunday.strftime('%Y/%m/%d'))
    with col4: st.metric("⚠️ 除外日数", f"{excluded_days}日")
    
    st.caption(f"💡 最新データが{latest_date.strftime('%A')}のため、分析精度向上のため前の日曜日({analysis_end_sunday.strftime('%Y/%m/%d')})までを分析対象としています。")
    st.markdown("---")
    
    st.subheader("📊 診療科別パフォーマンスダッシュボード（直近4週データ分析）")
    four_weeks_ago = analysis_end_sunday - pd.Timedelta(days=27)
    st.caption(f"🗓️ 分析対象期間: {four_weeks_ago.strftime('%Y/%m/%d')} ~ {analysis_end_sunday.strftime('%Y/%m/%d')}")

    perf_summary = ranking.get_department_performance_summary(df, target_dict, latest_date)

    if not perf_summary.empty:
        if '達成率(%)' not in perf_summary.columns:
            st.warning("パフォーマンスデータに達成率の列が見つかりません。")
        else:
            sorted_perf = perf_summary.sort_values("達成率(%)", ascending=False)
            
            def get_color_for_rate(rate):
                if rate >= 100: return "#28a745"
                if rate >= 80: return "#ffc107"
                return "#dc3545"

            cols = st.columns(3)
            for i, row in sorted_perf.iterrows():
                with cols[i % 3]:
                    rate = row["達成率(%)"]
                    color = get_color_for_rate(rate)
                    bar_width = min(rate, 100)
                    
                    html = f"""
                    <div style="background-color: {color}1A; border-left: 5px solid {color}; padding: 12px; border-radius: 5px; margin-bottom: 12px; height: 165px;">
                        <h5 style="margin: 0 0 10px 0; font-weight: bold; color: #333;">{row["診療科"]}</h5>
                        <div style="display: flex; justify-content: space-between; font-size: 0.9em;"><span>4週平均:</span><span style="font-weight: bold;">{row["4週平均"]:.1f} 件</span></div>
                        <div style="display: flex; justify-content: space-between; font-size: 0.9em;"><span>直近週実績:</span><span style="font-weight: bold;">{row["直近週実績"]:.0f} 件</span></div>
                        <div style="display: flex; justify-content: space-between; font-size: 0.9em; color: #666;"><span>目標:</span><span>{row["週次目標"]:.1f} 件</span></div>
                        <div style="display: flex; justify-content: space-between; font-size: 1.1em; color: {color}; margin-top: 5px;">
                            <span style="font-weight: bold;">達成率:</span><span style="font-weight: bold;">{rate:.1f}%</span>
                        </div>
                        <div style="background-color: #e9ecef; border-radius: 5px; height: 6px; margin-top: 5px;">
                            <div style="width: {bar_width}%; background-color: {color}; height: 6px; border-radius: 5px;"></div>
                        </div>
                    </div>
                    """
                    st.markdown(html, unsafe_allow_html=True)
            
            with st.expander("詳細データテーブル"): st.dataframe(sorted_perf)
    else:
        st.info("診療科別パフォーマンスを計算する十分なデータがありません。")
        
    st.markdown("---")
    st.subheader("📈 全身麻酔手術件数 週次推移（完全週データ）")
    summary = weekly.get_summary(df, use_complete_weeks=True)
    if not summary.empty:
        fig = trend_plots.create_weekly_summary_chart(summary, "", target_dict)
        st.plotly_chart(fig, use_container_width=True)

def render_department_page(df, target_dict, latest_date):
    st.title("🩺 診療科別分析")
    departments = sorted(df["実施診療科"].dropna().unique())
    if not departments: st.warning("データに診療科情報がありません。"); return
    selected_dept = st.selectbox("分析する診療科を選択", departments)
    dept_df = df[df['実施診療科'] == selected_dept]
    kpi_summary = ranking.get_kpi_summary(dept_df, latest_date)
    generic_plots.display_kpi_metrics(kpi_summary)
    st.markdown("---")
    summary = weekly.get_summary(df, department=selected_dept, use_complete_weeks=st.toggle("完全週データ", True))
    fig = trend_plots.create_weekly_dept_chart(summary, selected_dept, target_dict)
    st.plotly_chart(fig, use_container_width=True)
    st.markdown("---")
    st.header("🔍 詳細分析")
    tab1, tab2, tab3, tab4 = st.tabs(["術者分析", "時間分析", "統計情報", "累積実績"])
    with tab1:
        st.subheader(f"{selected_dept} 術者別件数 (Top 15)")
        expanded_df = surgeon.get_expanded_surgeon_df(dept_df)
        surgeon_summary = surgeon.get_surgeon_summary(expanded_df)
        if not surgeon_summary.empty: st.plotly_chart(generic_plots.plot_surgeon_ranking(surgeon_summary, 15, selected_dept), use_container_width=True)
    with tab2:
        st.subheader("曜日・月別 分布")
        gas_df = dept_df[dept_df['is_gas_20min']]
        if not gas_df.empty:
            col1, col2 = st.columns(2)
            with col1:
                weekday_dist = gas_df['手術実施日_dt'].dt.day_name().value_counts()
                st.plotly_chart(px.pie(values=weekday_dist.values, names=weekday_dist.index, title="曜日別分布"), use_container_width=True)
            with col2:
                month_dist = gas_df['手術実施日_dt'].dt.month_name().value_counts()
                st.plotly_chart(px.bar(x=month_dist.index, y=month_dist.values, title="月別分布", labels={'x':'月', 'y':'件数'}), use_container_width=True)
    with tab3:
        st.subheader("基本統計")
        desc_df = dept_df[dept_df['is_gas_20min']].describe(include='all').transpose()
        st.dataframe(desc_df.astype(str))
    with tab4:
        st.subheader(f"{selected_dept} 今年度 累積実績")
        weekly_target = target_dict.get(selected_dept)
        if weekly_target:
            cum_data = ranking.calculate_cumulative_cases(dept_df, weekly_target)
            if not cum_data.empty: st.plotly_chart(generic_plots.plot_cumulative_cases_chart(cum_data, f"{selected_dept} 累積実績"), use_container_width=True)
        else: st.info("この診療科の目標値が設定されていないため、累積目標は表示できません。")

def render_surgeon_page(df, target_dict, latest_date):
    st.title("👨‍⚕️ 術者分析")
    analysis_type = st.radio("分析タイプ", ["診療科別ランキング", "術者ごと時系列"], horizontal=True)
    with st.spinner("術者データを準備中..."):
        expanded_df = surgeon.get_expanded_surgeon_df(df)
    if expanded_df.empty:
        st.warning("分析可能な術者データがありません。"); return
    if analysis_type == "診療科別ランキング":
        departments = ["全診療科"] + sorted(df["実施診療科"].dropna().unique())
        selected_dept = st.selectbox("診療科で絞り込み", departments)
        top_n = st.slider("表示する術者数（上位）", 5, 50, 15)
        target_df = expanded_df
        if selected_dept != "全診療科": target_df = expanded_df[expanded_df['実施診療科'] == selected_dept]
        summary_df = surgeon.get_surgeon_summary(target_df)
        if not summary_df.empty: st.plotly_chart(generic_plots.plot_surgeon_ranking(summary_df, top_n, selected_dept), use_container_width=True)
    else: # 術者ごと時系列
        surgeons = sorted(expanded_df["実施術者"].dropna().unique())
        selected_surgeon = st.selectbox("分析する術者を選択", surgeons)
        surgeon_df = expanded_df[expanded_df['実施術者'] == selected_surgeon]
        st.header(f"{selected_surgeon} の週次実績")
        summary = weekly.get_summary(surgeon_df, use_complete_weeks=False)
        if not summary.empty:
            fig = trend_plots.create_weekly_dept_chart(summary, selected_surgeon, {})
            st.plotly_chart(fig, use_container_width=True)

def render_prediction_page(df, target_dict, latest_date):
    st.title("🔮 将来予測")
    
    # 予測対象の説明を追加
    with st.expander("📊 予測データの詳細説明", expanded=False):
        st.markdown("""
        **予測対象データ**: 全身麻酔手術（20分以上）
        
        **重要**: 休日データの扱いについては実装により異なります
        - 平日のみ対象の場合: 土日祝日、年末年始は除外
        - 全日対象の場合: 休日の緊急手術も含む
        
        **フィルタ条件**:
        - `is_gas_20min = True` （全身麻酔20分以上）
        - `is_weekday` の使用有無は実装依存
        """)
    
    tab1, tab2, tab3 = st.tabs(["将来予測", "モデル検証", "パラメータ最適化"])

    with tab1:
        st.header("将来予測")
        pred_target = st.radio("予測対象", ["病院全体", "診療科別"], horizontal=True, key="pred_target")
        department = None
        if pred_target == "診療科別":
            departments = sorted(df["実施診療科"].dropna().unique())
            department = st.selectbox("診療科を選択", departments, key="pred_dept_select")
        model_type = st.selectbox("予測モデル", ["hwes", "arima", "moving_avg"], format_func=lambda x: {"hwes":"Holt-Winters", "arima":"ARIMA", "moving_avg":"移動平均"}[x])
        pred_period = st.selectbox("予測期間", ["fiscal_year", "calendar_year", "six_months"], format_func=lambda x: {"fiscal_year":"年度末まで", "calendar_year":"年末まで", "six_months":"6ヶ月先まで"}[x])
        
        if st.button("予測を実行", type="primary", key="run_prediction"):
            with st.spinner("予測計算中..."):
                result_df, metrics = forecasting.predict_future(df, latest_date, department=department, model_type=model_type, prediction_period=pred_period)
                
                if metrics.get("message"):
                    st.warning(metrics["message"])
                else:
                    title = f"{department or '病院全体'} {metrics.get('予測モデル','')}モデルによる予測"
                    
                    # グラフ表示
                    fig = generic_plots.create_forecast_chart(result_df, title)
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # 予測に使用された実際のデータを詳細分析
                    st.header("🔍 予測入力データの詳細分析")
                    
                    if department:
                        base_data = df[df['実施診療科'] == department]
                    else:
                        base_data = df
                    
                    # 各段階でのデータ件数を詳細に表示
                    total_data = len(base_data)
                    gas_data = base_data[base_data['is_gas_20min']]
                    gas_count = len(gas_data)
                    
                    # 平日・休日の内訳
                    weekday_data = gas_data[gas_data['is_weekday']]
                    weekend_data = gas_data[~gas_data['is_weekday']]
                    weekday_count = len(weekday_data)
                    weekend_count = len(weekend_data)
                    
                    # 曜日別の詳細分析
                    day_analysis = gas_data.groupby(gas_data['手術実施日_dt'].dt.day_name()).size()
                    
                    col1, col2 = st.columns([1, 1])
                    
                    with col1:
                        st.subheader("📊 データフィルタリング結果")
                        filter_summary = pd.DataFrame({
                            'フィルタ段階': [
                                '1. 全データ',
                                '2. 全身麻酔(20分以上)',
                                '3. うち平日のみ',
                                '4. うち休日のみ'
                            ],
                            '件数': [
                                f"{total_data:,}件",
                                f"{gas_count:,}件", 
                                f"{weekday_count:,}件",
                                f"{weekend_count:,}件"
                            ],
                            '割合': [
                                "100%",
                                f"{gas_count/total_data*100:.1f}%" if total_data > 0 else "0%",
                                f"{weekday_count/gas_count*100:.1f}%" if gas_count > 0 else "0%",
                                f"{weekend_count/gas_count*100:.1f}%" if gas_count > 0 else "0%"
                            ]
                        })
                        st.dataframe(filter_summary, hide_index=True, use_container_width=True)
                    
                    with col2:
                        st.subheader("📅 曜日別内訳")
                        if not day_analysis.empty:
                            day_df = pd.DataFrame({
                                '曜日': day_analysis.index,
                                '件数': day_analysis.values
                            })
                            # 曜日順にソート
                            day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
                            day_df['曜日順'] = day_df['曜日'].map({day: i for i, day in enumerate(day_order)})
                            day_df = day_df.sort_values('曜日順').drop('曜日順', axis=1)
                            st.dataframe(day_df, hide_index=True, use_container_width=True)
                    
                    # 重要な確認メッセージ
                    if weekend_count > 0:
                        st.warning(f"""
                        ⚠️ **重要確認**: 休日にも{weekend_count}件の全身麻酔手術があります。
                        
                        **予測モデルがどちらを使用しているかは `forecasting.py` の実装によります：**
                        - 平日のみ使用: {weekday_count}件のデータで予測
                        - 全日使用: {gas_count}件のデータで予測
                        
                        実際に使用されているデータは、予測結果の実績部分の件数と比較して確認できます。
                        """)
                    else:
                        st.info(f"✅ 対象期間中の休日手術は0件のため、平日・全日どちらでも同じ結果になります。")
                    
                    # より詳細な期間分析
                    st.subheader("📅 予測データの期間分析")
                    
                    if '種別' in result_df.columns:
                        actual_forecast_df = result_df[result_df['種別'] == '実績']
                        if not actual_forecast_df.empty:
                            # 予測で使用された実績期間を確認
                            if 'month_start' in actual_forecast_df.columns:
                                forecast_start = actual_forecast_df['month_start'].min()
                                forecast_end = actual_forecast_df['month_start'].max()
                                forecast_months = len(actual_forecast_df)
                                
                                period_info = pd.DataFrame({
                                    '項目': [
                                        '予測用実績データ期間（開始）',
                                        '予測用実績データ期間（終了）',
                                        '予測用データポイント数',
                                        '予測値の意味',
                                        '生データとの関係'
                                    ],
                                    '値': [
                                        forecast_start.strftime('%Y年%m月') if pd.notna(forecast_start) else '不明',
                                        forecast_end.strftime('%Y年%m月') if pd.notna(forecast_end) else '不明',
                                        f"{forecast_months}ヶ月分",
                                        "月次集計値（月平均 or 月総数）",
                                        f"生データ{gas_count:,}件 → 月次集計{forecast_months}ヶ月"
                                    ]
                                })
                                
                                st.dataframe(period_info, hide_index=True, use_container_width=True)
                                
                                # 月あたりの平均件数を計算
                                if forecast_months > 0:
                                    avg_per_month_from_raw = gas_count / forecast_months
                                    avg_per_month_from_forecast = actual_forecast_df['値'].mean()
                                    
                                    st.info(f"""
                                    📊 **月次データの検証**:
                                    - 生データから計算した月平均: {avg_per_month_from_raw:.1f}件/月
                                    - 予測データの月平均: {avg_per_month_from_forecast:.1f}件/月
                                    
                                    {"✅ 値が近似→予測は月総数を使用" if abs(avg_per_month_from_raw - avg_per_month_from_forecast) < avg_per_month_from_raw * 0.1 
                                     else "⚠️ 値が異なる→予測は日平均など別の単位を使用"}
                                    """)
                    
                    # 予測サマリーテーブル表示
                    st.header("📋 予測サマリー")
                    
                    try:
                        summary_df, monthly_df = generic_plots.create_forecast_summary_table(
                            result_df, target_dict, department, source_df=df  # 生データを渡す
                        )
                        
                        if not summary_df.empty:
                            col1, col2 = st.columns([1, 1])
                            
                            with col1:
                                st.subheader("年度予測サマリー")
                                st.dataframe(summary_df, hide_index=True, use_container_width=True)
                                
                                # 実績値との整合性チェック
                                if '種別' in result_df.columns:
                                    actual_from_forecast = result_df[result_df['種別'] == '実績']['値'].sum()
                                    st.caption(f"""
                                    **整合性チェック**: 
                                    - 予測結果の実績部分: {actual_from_forecast:.0f}件
                                    - 平日全身麻酔データ: {weekday_count}件
                                    - 全日全身麻酔データ: {gas_count}件
                                    """)
                            
                            with col2:
                                st.subheader("月別予測詳細")
                                if not monthly_df.empty:
                                    st.dataframe(monthly_df, hide_index=True, use_container_width=True)
                                else:
                                    st.info("月別予測データがありません")
                        else:
                            st.info("予測サマリーを生成できませんでした")
                            
                    except Exception as e:
                        st.error(f"サマリーテーブル生成エラー: {str(e)}")
                        st.write("エラー詳細:", e)
                    
                    # モデル評価指標表示
                    with st.expander("📊 モデル評価指標詳細"):
                        st.write(metrics)
                    
    with tab2:
        st.header("予測モデルの精度検証")
        val_target = st.radio("検証対象", ["病院全体", "診療科別"], horizontal=True, key="val_target")
        val_dept = None
        if val_target == "診療科別": val_dept = st.selectbox("診療科を選択", sorted(df["実施診療科"].dropna().unique()), key="val_dept")
        val_period = st.slider("検証期間（月数）", 3, 12, 6)
        if st.button("検証実行", key="run_validation"):
            with st.spinner("モデル検証中..."):
                metrics_df, train, test, preds, rec = forecasting.validate_model(df, department=val_dept, validation_period=val_period)
                if not metrics_df.empty:
                    st.success(rec); st.dataframe(metrics_df)
                    st.plotly_chart(generic_plots.create_validation_chart(train, test, preds), use_container_width=True)
                else: st.error("モデル検証に失敗しました。")
    with tab3:
        st.header("パラメータ最適化 (Holt-Winters)")
        opt_target = st.radio("最適化対象", ["病院全体", "診療科別"], horizontal=True, key="opt_target")
        opt_dept = None
        if opt_target == "診療科別": opt_dept = st.selectbox("診療科を選択", sorted(df["実施診療科"].dropna().unique()), key="opt_dept")
        if st.button("最適化実行", key="run_opt"):
            with st.spinner("最適化計算中..."):
                params, desc = forecasting.optimize_hwes_params(df, department=opt_dept)
                if params: st.success(f"最適モデル: {desc}"); st.write(params)
                else: st.error(desc)

# --- メイン実行部 ---
def main():
    initialize_session_state()
    render_sidebar()
    render_page_content()

if __name__ == "__main__":
    main()